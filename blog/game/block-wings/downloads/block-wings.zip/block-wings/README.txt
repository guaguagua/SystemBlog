方块飞行 · Block Wings

在线游玩：https://guaguagua.github.io/SystemBlog/blog/game/block-wings/

本地运行：安装 Python 3 后，在解压目录执行 python open-game.py，浏览器会自动打开。请勿直接双击 index.html，游戏的素材加载需要 HTTP。

所有游戏素材和语音均已包含，无需 Node.js、npm 或后端服务。移动鼠标或拖动手指驾驶；自动射击；英文短句触发魔法。
